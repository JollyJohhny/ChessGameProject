﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessGame
{
    class Players
    {
        //These static variables will be used to store the players name
        public static string PlayerOneName { get; set; }
        public static string PlayerTwoName { get; set; }
        public static int Count { get; set; }

    }
}
